const getCodeScript = `
  var userSolution = ace.edit("ace-editor").getValue();
  var scriptInjectedElement = document.createElement("pre");
  scriptInjectedElement.innerText+=userSolution;
  scriptInjectedElement.setAttribute("id","extractedUserSolution");
  scriptInjectedElement.setAttribute("style","color:#fff");
  document.body.appendChild(scriptInjectedElement);
  console.log("Inside extract code  111111");
  `;

var extractCodeScript = document.createElement("script");
extractCodeScript.id = "extractCodeScript";
extractCodeScript.appendChild(document.createTextNode(getCodeScript));

(document.body || document.head || document.documentElement).appendChild(
  extractCodeScript
);

console.log("Inside extract code");